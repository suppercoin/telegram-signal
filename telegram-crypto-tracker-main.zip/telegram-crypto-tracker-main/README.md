# Telegram Crypto Tracker

A small telegram bot to track cryptocurrency prices

Live Demo: <https://t.me/lordghostx_cryptobot>

![telegram bot image](telegram-bot.jpg)
